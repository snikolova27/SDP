#pragma once

struct Pair
{   public:
    int cntInFirst = 0;
    int cntInSecond = 0;
};